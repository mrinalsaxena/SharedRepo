package com.assignment;

public class InvalidTradeException extends Exception {

	public InvalidTradeException(String message){
		super(message);
	}
		
}
